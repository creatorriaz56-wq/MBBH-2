window.MBBH_I18N = {
    getLang() {
        return localStorage.getItem('mbbh_lang') || 'bn';
    },
    setLang(lang) {
        localStorage.setItem('mbbh_lang', lang);
        this.apply(lang);
        window.dispatchEvent(new CustomEvent('mbbh-lang-change', { detail: lang }));
    },
    toggle() {
        this.setLang(this.getLang() === 'bn' ? 'en' : 'bn');
    },
    pick(bn, en) {
        return this.getLang() === 'bn' ? bn : en;
    },
    apply(lang = this.getLang()) {
        document.documentElement.lang = lang;
        document.querySelectorAll('[data-bn][data-en]').forEach((el) => {
            el.textContent = lang === 'bn' ? el.getAttribute('data-bn') : el.getAttribute('data-en');
        });
        document.querySelectorAll('[data-ph-bn][data-ph-en]').forEach((el) => {
            el.setAttribute('placeholder', lang === 'bn' ? el.getAttribute('data-ph-bn') : el.getAttribute('data-ph-en'));
        });
        const btn = document.getElementById('lang-toggle-btn');
        if (btn) {
            btn.textContent = lang === 'bn' ? '🇬🇧 English' : '🇧🇩 বাংলা';
        }
    }
};

document.addEventListener('DOMContentLoaded', () => {
    window.MBBH_I18N.apply();
});
