/**
 * MBBH Shared API Client
 * - Automatically targets same-origin when hosted locally or behind Node/Render.
 * - On GitHub Pages (creatorriaz56-wq.github.io), targets the configured Render Free Web Service URL.
 * - Sends both HttpOnly cookies (credentials: 'include') AND revocable Bearer session token
 *   stored in sessionStorage so cross-site GitHub Pages -> Render auth works reliably on mobile
 *   browsers (iOS Safari / Chrome Android) even when third-party cookies are blocked.
 */
(function () {
    const PRODUCTION_RENDER_API_URL = 'https://mbbh-web-backend.onrender.com';
    const TOKEN_STORAGE_KEY = 'mbbh_session_token';

    function resolveApiBase() {
        const params = new URLSearchParams(window.location.search);
        const override = params.get('api');
        if (override && /^https?:\/\//i.test(override)) {
            localStorage.setItem('mbbh_api_base', override.replace(/\/$/, ''));
        }
        const saved = localStorage.getItem('mbbh_api_base');
        if (saved && /^https?:\/\//i.test(saved)) {
            return saved.replace(/\/$/, '');
        }
        const host = window.location.hostname;
        if (host === 'localhost' || host === '127.0.0.1') {
            return '';
        }
        if (host.endsWith('github.io')) {
            return PRODUCTION_RENDER_API_URL;
        }
        return '';
    }

    const API_BASE = resolveApiBase();

    function getStoredToken() {
        try {
            return sessionStorage.getItem(TOKEN_STORAGE_KEY) || '';
        } catch {
            return '';
        }
    }

    function setStoredToken(token) {
        try {
            if (token) {
                sessionStorage.setItem(TOKEN_STORAGE_KEY, token);
            } else {
                sessionStorage.removeItem(TOKEN_STORAGE_KEY);
            }
        } catch {}
    }

    async function request(path, options = {}) {
        const controller = new AbortController();
        // Render free tier can take 30-50s on cold start
        const timeoutMs = options.timeoutMs || 55000;
        const timer = setTimeout(() => controller.abort(), timeoutMs);

        const headers = {
            'Content-Type': 'application/json',
            ...(options.headers || {})
        };
        const token = getStoredToken();
        if (token && !headers.Authorization) {
            headers.Authorization = `Bearer ${token}`;
        }

        try {
            const res = await fetch(`${API_BASE}${path}`, {
                method: options.method || 'GET',
                credentials: 'include',
                headers,
                body: options.body ? JSON.stringify(options.body) : undefined,
                signal: controller.signal
            });
            const data = await res.json().catch(() => ({}));
            if (res.status === 401) {
                setStoredToken('');
            }
            return { ok: res.ok, status: res.status, data };
        } finally {
            clearTimeout(timer);
        }
    }

    window.MBBH_API = {
        API_BASE,
        request,
        getCaptcha: () => request('/api/v1/auth/captcha'),
        register: async (payload) => {
            const res = await request('/api/v1/auth/register', { method: 'POST', body: payload });
            if (res.ok && res.data && res.data.token) {
                setStoredToken(res.data.token);
            }
            return res;
        },
        login: async (payload) => {
            const res = await request('/api/v1/auth/login', { method: 'POST', body: payload });
            if (res.ok && res.data && res.data.token) {
                setStoredToken(res.data.token);
            }
            return res;
        },
        me: () => request('/api/v1/auth/me'),
        logout: async () => {
            try {
                return await request('/api/v1/auth/logout', { method: 'POST' });
            } finally {
                setStoredToken('');
            }
        },
        getDashboard: () => request('/api/v1/platform/dashboard'),
        completeTask: (payload) => request('/api/v1/platform/tasks/complete', { method: 'POST', body: payload }),
        bindWallet: (payload) => request('/api/v1/platform/wallet/bind', { method: 'POST', body: payload }),
        submitRecharge: (payload) => request('/api/v1/platform/recharge', { method: 'POST', body: payload }),
        upgradeVip: (tier) => request('/api/v1/platform/vip/upgrade', { method: 'POST', body: { tier } }),
        submitWithdraw: (payload) => request('/api/v1/platform/withdraw', { method: 'POST', body: payload })
    };
})();
