const express = require('express');
const db = require('../db/adapter');
const {
    CURRENT_ALGO,
    generateSalt,
    hashPassword,
    hashLegacyAndroidSha256,
    verifyPasswordWithAlgo,
    generateSessionToken,
    hashToken,
    generateId,
    generateReferralCode,
    generateUid,
    timingSafeHexEqual
} = require('../security/crypto');
const { createCaptcha, verifyAndConsumeCaptcha } = require('../security/captcha');
const { checkLoginRateLimit, recordAuthEvent } = require('../security/rateLimiter');
const {
    SESSION_COOKIE_NAME,
    SESSION_TTL_MS,
    buildCookieOptions,
    requireAuth
} = require('../middleware/auth');
const {
    getDhakaDateStr,
    isValidBangladeshPhone,
    getBangladeshOperator
} = require('../config/plans');

const router = express.Router();

function serializeUser(u) {
    return {
        id: u.id,
        phone: u.phone,
        operator: u.operator,
        name: u.name,
        balance: Number(u.balance || 0),
        personalWalletBalance: Number(u.personal_wallet_balance || 0),
        vipTier: Number(u.vip_tier || 0),
        vipExpireDays: Number(u.vip_expire_days ?? 2),
        referralCode: u.referral_code,
        referredBy: u.referred_by || null,
        boundAccountName: u.bound_account_name || null,
        boundWalletType: u.bound_wallet_type || null,
        boundWalletNumber: u.bound_wallet_number || null,
        hasPaymentPin: Boolean(u.payment_pin_hash),
        todayEarnings: Number(u.today_earnings || 0),
        yesterdayEarnings: Number(u.yesterday_earnings || 0),
        monthlyEarnings: Number(u.monthly_earnings || 0),
        referralIncome: Number(u.referral_income || 0),
        teamCommission: Number(u.team_commission || 0),
        totalRecharged: Number(u.total_recharged || 0),
        totalWithdrawn: Number(u.total_withdrawn || 0),
        completedTasksToday: Number(u.completed_tasks_today || 0),
        lastTaskResetDate: u.last_task_reset_date,
        registrationDate: u.registration_date,
        accountOrigin: u.account_origin || 'web_registered'
    };
}

async function createSessionForUser(userId, clientType, req) {
    const rawToken = generateSessionToken();
    const tokenHash = hashToken(rawToken);
    const expiresAt = new Date(Date.now() + SESSION_TTL_MS).toISOString();
    const ip = req.ip || req.socket?.remoteAddress || '';
    const ua = (req.headers['user-agent'] || '').slice(0, 240);

    await db.query(
        `INSERT INTO sessions (id, user_id, token_hash, client_type, user_agent, ip_address, expires_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [generateId('SES'), userId, tokenHash, clientType, ua, ip.slice(0, 64), expiresAt]
    );
    return { rawToken, expiresAt };
}

async function applyDhakaMidnightResetIfNeeded(userRow) {
    const todayDhaka = getDhakaDateStr();
    if (!userRow.last_task_reset_date || userRow.last_task_reset_date === todayDhaka) {
        return userRow;
    }
    const newExpire = Math.max(0, Number(userRow.vip_expire_days || 0) - 1);
    const updatedYesterday = Number(userRow.today_earnings || 0);
    await db.query(
        `UPDATE users
         SET yesterday_earnings = $1,
             today_earnings = 0,
             completed_tasks_today = 0,
             vip_expire_days = $2,
             last_task_reset_date = $3,
             updated_at = $4
         WHERE id = $5`,
        [updatedYesterday, newExpire, todayDhaka, new Date().toISOString(), userRow.id]
    );
    return {
        ...userRow,
        yesterday_earnings: updatedYesterday,
        today_earnings: 0,
        completed_tasks_today: 0,
        vip_expire_days: newExpire,
        last_task_reset_date: todayDhaka
    };
}

// GET /api/v1/auth/captcha
router.get('/captcha', async (req, res, next) => {
    try {
        const ip = req.ip || req.socket?.remoteAddress || '';
        const challenge = await createCaptcha(ip);
        res.setHeader('Cache-Control', 'no-store');
        return res.json({
            success: true,
            ...challenge
        });
    } catch (err) {
        return next(err);
    }
});

// POST /api/v1/auth/register
router.post('/register', async (req, res, next) => {
    try {
        const body = req.body || {};
        const phone = String(body.phone || '').trim();
        const password = String(body.password || '');
        const confirmPassword = String(body.confirmPassword ?? body.confirm_password ?? '');
        const referralCodeInput = String(body.referralCode ?? body.referral ?? '').trim();
        const captchaId = String(body.captchaId || '').trim();
        const captchaInput = String(body.captcha || '').trim();
        const ip = req.ip || req.socket?.remoteAddress || '';

        if (!isValidBangladeshPhone(phone)) {
            return res.status(400).json({
                success: false,
                message: 'সঠিক ১১-সংখ্যার বাংলাদেশি মোবাইল নম্বর দিন (০১৩–০১৯)।',
                messageEn: 'Enter a valid 11-digit Bangladeshi mobile number (013–019).'
            });
        }

        if (password.length < 6 || password.length > 128) {
            return res.status(400).json({
                success: false,
                message: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।',
                messageEn: 'Password must be between 6 and 128 characters.'
            });
        }

        if (password !== confirmPassword) {
            return res.status(400).json({
                success: false,
                message: 'পাসওয়ার্ড দুটি মেলেনি! পুনরায় যাচাই করুন।',
                messageEn: 'Passwords do not match! Please verify.'
            });
        }

        const capResult = await verifyAndConsumeCaptcha(captchaId, captchaInput);
        if (!capResult.valid) {
            await recordAuthEvent({ phone, action: 'register', success: false, ipAddress: ip, detail: 'captcha_failed' });
            return res.status(400).json({
                success: false,
                message: capResult.messageBn,
                messageEn: capResult.messageEn
            });
        }

        const createdUser = await db.withTransaction(async (tx) => {
            const existing = await tx.query(`SELECT id FROM users WHERE phone = $1`, [phone]);
            if (existing.rows.length > 0) {
                return { duplicate: true };
            }

            const uid = generateUid();
            const userRefCode = generateReferralCode();
            const salt = generateSalt(16);
            const hash = hashPassword(password, salt);
            const operator = getBangladeshOperator(phone) || 'Unknown';
            const todayDhaka = getDhakaDateStr();
            const cleanRefBy = referralCodeInput && referralCodeInput !== userRefCode ? referralCodeInput : null;

            await tx.query(
                `INSERT INTO users (
                    id, phone, operator, name, password_hash, password_salt, password_algo,
                    balance, personal_wallet_balance, vip_tier, vip_expire_days,
                    referral_code, referred_by, last_task_reset_date, registration_date, account_origin
                ) VALUES ($1,$2,$3,$4,$5,$6,$7, 0.00, 0.00, 0, 2, $8,$9,$10,$11,'web_registered')`,
                [uid, phone, operator, `Member_${uid.slice(-4)}`, hash, salt, CURRENT_ALGO, userRefCode, cleanRefBy, todayDhaka, todayDhaka]
            );

            // Link up to 3 referral tiers if inviter exists
            if (cleanRefBy) {
                const inviter1Res = await tx.query(`SELECT id, referred_by FROM users WHERE referral_code = $1`, [cleanRefBy]);
                if (inviter1Res.rows.length > 0) {
                    const inv1 = inviter1Res.rows[0];
                    await tx.query(
                        `INSERT INTO referrals (id, inviter_user_id, invited_user_id, tier, commission_earned)
                         VALUES ($1, $2, $3, 1, 0.00) ON CONFLICT DO NOTHING`,
                        [generateId('REF'), inv1.id, uid]
                    );
                    if (inv1.referred_by) {
                        const inviter2Res = await tx.query(`SELECT id, referred_by FROM users WHERE referral_code = $1`, [inv1.referred_by]);
                        if (inviter2Res.rows.length > 0) {
                            const inv2 = inviter2Res.rows[0];
                            await tx.query(
                                `INSERT INTO referrals (id, inviter_user_id, invited_user_id, tier, commission_earned)
                                 VALUES ($1, $2, $3, 2, 0.00) ON CONFLICT DO NOTHING`,
                                [generateId('REF'), inv2.id, uid]
                            );
                            if (inv2.referred_by) {
                                const inviter3Res = await tx.query(`SELECT id FROM users WHERE referral_code = $1`, [inv2.referred_by]);
                                if (inviter3Res.rows.length > 0) {
                                    await tx.query(
                                        `INSERT INTO referrals (id, inviter_user_id, invited_user_id, tier, commission_earned)
                                         VALUES ($1, $2, $3, 3, 0.00) ON CONFLICT DO NOTHING`,
                                        [generateId('REF'), inviter3Res.rows[0].id, uid]
                                    );
                                }
                            }
                        }
                    }
                }
            }

            const fetched = await tx.query(`SELECT * FROM users WHERE id = $1`, [uid]);
            return { duplicate: false, user: fetched.rows[0] };
        });

        if (createdUser.duplicate) {
            await recordAuthEvent({ phone, action: 'register', success: false, ipAddress: ip, detail: 'duplicate_phone' });
            return res.status(409).json({
                success: false,
                message: 'এই ফোন নম্বরটি ইতিমধ্যে নিবন্ধিত! অনুগ্রহ করে লগইন করুন।',
                messageEn: 'This phone number is already registered! Please log in.'
            });
        }

        const { rawToken, expiresAt } = await createSessionForUser(createdUser.user.id, 'web', req);
        res.cookie(SESSION_COOKIE_NAME, rawToken, buildCookieOptions(req));
        await recordAuthEvent({ phone, action: 'register', success: true, ipAddress: ip, detail: 'registered' });

        return res.status(201).json({
            success: true,
            message: 'নিবন্ধন সফল হয়েছে! MBBH প্ল্যাটফর্মে স্বাগতম।',
            messageEn: 'Registration successful! Welcome to MBBH.',
            token: rawToken,
            expiresAt,
            user: serializeUser(createdUser.user)
        });
    } catch (err) {
        return next(err);
    }
});

// POST /api/v1/auth/login
router.post('/login', async (req, res, next) => {
    try {
        const body = req.body || {};
        const phone = String(body.phone || '').trim();
        const password = String(body.password || '');
        const captchaId = String(body.captchaId || '').trim();
        const captchaInput = String(body.captcha || '').trim();
        const ip = req.ip || req.socket?.remoteAddress || '';

        if (!isValidBangladeshPhone(phone)) {
            return res.status(400).json({
                success: false,
                message: 'অকার্যকর মোবাইল নম্বর! সঠিক ১১-সংখ্যার বাংলাদেশি নম্বর দিন।',
                messageEn: 'Invalid phone! Enter a valid 11-digit Bangladeshi mobile number.'
            });
        }

        const rate = checkLoginRateLimit(phone, ip);
        if (!rate.allowed) {
            return res.status(429).json({
                success: false,
                message: `বারবার ভুল চেষ্টার কারণে অ্যাকাউন্ট সুরক্ষা লক! ${rate.remainingSeconds} সেকেন্ড পর আবার চেষ্টা করুন।`,
                messageEn: `Too many failed login attempts! Account locked for ${rate.remainingSeconds} seconds.`
            });
        }

        const capResult = await verifyAndConsumeCaptcha(captchaId, captchaInput);
        if (!capResult.valid) {
            await recordAuthEvent({ phone, action: 'login', success: false, ipAddress: ip, detail: 'captcha_failed' });
            return res.status(400).json({
                success: false,
                message: capResult.messageBn,
                messageEn: capResult.messageEn
            });
        }

        const userRes = await db.query(`SELECT * FROM users WHERE phone = $1`, [phone]);
        if (userRes.rows.length === 0) {
            await recordAuthEvent({ phone, action: 'login', success: false, ipAddress: ip, detail: 'user_not_found' });
            return res.status(401).json({
                success: false,
                message: 'এই ফোন নম্বরে কোনো অ্যাকাউন্ট পাওয়া যায়নি বা তথ্য ভুল! প্রথমে নিবন্ধন করুন।',
                messageEn: 'Invalid credentials or account not found. Please register first.'
            });
        }

        let userRow = userRes.rows[0];
        const check = verifyPasswordWithAlgo(
            password,
            userRow.password_salt,
            userRow.password_hash,
            userRow.password_algo || CURRENT_ALGO
        );

        if (!check.valid) {
            await recordAuthEvent({ phone, action: 'login', success: false, ipAddress: ip, detail: 'bad_password' });
            return res.status(401).json({
                success: false,
                message: 'ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন।',
                messageEn: 'Incorrect password! Please enter the correct password.'
            });
        }

        // Transparently upgrade legacy password hash to PBKDF2-100k on verified login
        if (check.needsRehash) {
            const newSalt = generateSalt(16);
            const newHash = hashPassword(password, newSalt);
            await db.query(
                `UPDATE users SET password_hash = $1, password_salt = $2, password_algo = $3, updated_at = $4 WHERE id = $5`,
                [newHash, newSalt, CURRENT_ALGO, new Date().toISOString(), userRow.id]
            );
        }

        userRow = await applyDhakaMidnightResetIfNeeded(userRow);
        const clientType = body.clientType === 'android' ? 'android' : 'web';
        const { rawToken, expiresAt } = await createSessionForUser(userRow.id, clientType, req);

        res.cookie(SESSION_COOKIE_NAME, rawToken, buildCookieOptions(req));
        await recordAuthEvent({ phone, action: 'login', success: true, ipAddress: ip, detail: 'logged_in' });

        return res.json({
            success: true,
            message: 'লগইন সফল হয়েছে! MBBH প্ল্যাটফর্মে স্বাগতম।',
            messageEn: 'Login successful! Welcome to MBBH.',
            token: rawToken,
            expiresAt,
            user: serializeUser(userRow)
        });
    } catch (err) {
        return next(err);
    }
});

// GET /api/v1/auth/me
router.get('/me', requireAuth, async (req, res, next) => {
    try {
        const updatedUser = await applyDhakaMidnightResetIfNeeded(req.auth.user);
        return res.json({
            success: true,
            user: serializeUser(updatedUser)
        });
    } catch (err) {
        return next(err);
    }
});

// POST /api/v1/auth/logout
router.post('/logout', async (req, res, next) => {
    try {
        const { extractRawToken } = require('../middleware/auth');
        const rawToken = extractRawToken(req);
        if (rawToken) {
            const tokenHash = hashToken(rawToken);
            await db.query(
                `UPDATE sessions SET revoked_at = $1 WHERE token_hash = $2 AND revoked_at IS NULL`,
                [new Date().toISOString(), tokenHash]
            );
        }
        res.clearCookie(SESSION_COOKIE_NAME, { ...buildCookieOptions(req), maxAge: undefined });
        return res.json({
            success: true,
            message: 'সফলভাবে লগআউট করা হয়েছে।',
            messageEn: 'Logged out successfully.'
        });
    } catch (err) {
        return next(err);
    }
});

// POST /api/v1/auth/migrate-legacy
// Safe zero-loss endpoint reserved for the future approved Android update to sync legacy SharedPreferences accounts.
router.post('/migrate-legacy', async (req, res, next) => {
    try {
        const body = req.body || {};
        const phone = String(body.phone || '').trim();
        const password = String(body.password || '');
        const legacyHash = String(body.legacyPasswordHash || '').trim();
        const legacySalt = String(body.legacyPasswordSalt || '').trim();
        const snapshot = body.snapshot || {};

        if (!isValidBangladeshPhone(phone) || !password || !legacyHash || !legacySalt) {
            return res.status(400).json({
                success: false,
                message: 'অসম্পূর্ণ মাইগ্রেশন তথ্য।',
                messageEn: 'Incomplete migration payload.'
            });
        }

        // Verify caller actually knows the plaintext password matching Android's legacy SHA-256 hash
        const expectedAndroidHash = hashLegacyAndroidSha256(password, legacySalt);
        if (!timingSafeHexEqual(expectedAndroidHash, legacyHash)) {
            return res.status(401).json({
                success: false,
                message: 'অ্যাকাউন্টের পাসওয়ার্ড যাচাই ব্যর্থ হয়েছে।',
                messageEn: 'Legacy password verification failed.'
            });
        }

        const outcome = await db.withTransaction(async (tx) => {
            const existingRes = await tx.query(`SELECT * FROM users WHERE phone = $1`, [phone]);
            if (existingRes.rows.length > 0) {
                // Conflict protection: never overwrite or zero out existing server account
                const existing = existingRes.rows[0];
                const incomingBalance = Number(snapshot.balance || 0);
                await tx.query(
                    `INSERT INTO migration_conflicts (id, phone, existing_user_id, existing_balance, incoming_balance, source, payload_json)
                     VALUES ($1, $2, $3, $4, $5, 'android_shared_prefs', $6)`,
                    [generateId('CONF'), phone, existing.id, Number(existing.balance || 0), incomingBalance, JSON.stringify(snapshot)]
                );
                return { status: 'conflict_recorded', user: existing };
            }

            const newSalt = generateSalt(16);
            const newHash = hashPassword(password, newSalt);
            const uid = String(snapshot.id || generateUid());
            const refCode = String(snapshot.referralCode || generateReferralCode());
            const todayDhaka = getDhakaDateStr();

            await tx.query(
                `INSERT INTO users (
                    id, phone, operator, name, password_hash, password_salt, password_algo,
                    balance, personal_wallet_balance, vip_tier, vip_expire_days,
                    referral_code, referred_by, bound_account_name, bound_wallet_type, bound_wallet_number,
                    today_earnings, yesterday_earnings, monthly_earnings, referral_income, team_commission,
                    total_recharged, total_withdrawn, completed_tasks_today,
                    last_task_reset_date, registration_date, account_origin, migrated_from_device_at
                ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,'migrated_android',$27)`,
                [
                    uid,
                    phone,
                    getBangladeshOperator(phone) || 'Unknown',
                    String(snapshot.name || `Member_${uid.slice(-4)}`),
                    newHash,
                    newSalt,
                    CURRENT_ALGO,
                    Math.max(0, Number(snapshot.balance || 0)),
                    Math.max(0, Number(snapshot.personalWalletBalance || 0)),
                    Math.min(9, Math.max(0, Number(snapshot.vipTier || 0))),
                    Math.max(0, Number(snapshot.vipExpireDays ?? 2)),
                    refCode,
                    snapshot.referredBy || null,
                    snapshot.boundAccountName || null,
                    snapshot.boundWalletType || null,
                    snapshot.boundWalletNumber || null,
                    Math.max(0, Number(snapshot.todayEarnings || 0)),
                    Math.max(0, Number(snapshot.yesterdayEarnings || 0)),
                    Math.max(0, Number(snapshot.monthlyEarnings || 0)),
                    Math.max(0, Number(snapshot.referralIncome || 0)),
                    Math.max(0, Number(snapshot.teamCommission || 0)),
                    Math.max(0, Number(snapshot.totalRecharged || 0)),
                    Math.max(0, Number(snapshot.totalWithdrawn || 0)),
                    Math.max(0, Number(snapshot.completedTasksToday || 0)),
                    String(snapshot.lastTaskResetDate || todayDhaka),
                    String(snapshot.registrationDate || todayDhaka),
                    new Date().toISOString()
                ]
            );

            const txs = Array.isArray(snapshot.transactions) ? snapshot.transactions : [];
            for (const item of txs) {
                const trxId = String(item.trxId || '').trim();
                if (!trxId) continue;
                await tx.query(
                    `INSERT INTO transactions (id, user_id, type, method, amount, balance_before, balance_after, trx_id, status, note)
                     VALUES ($1, $2, $3, $4, $5, 0, 0, $6, $7, 'Migrated from Android local storage')
                     ON CONFLICT DO NOTHING`,
                    [
                        generateId('TX'),
                        uid,
                        String(item.type || 'LEGACY'),
                        String(item.method || 'UNKNOWN'),
                        Math.max(0, Number(item.amount || 0)),
                        trxId,
                        String(item.status || 'SUCCESS')
                    ]
                );
            }

            const inserted = await tx.query(`SELECT * FROM users WHERE id = $1`, [uid]);
            return { status: 'migrated', user: inserted.rows[0] };
        });

        const { rawToken, expiresAt } = await createSessionForUser(outcome.user.id, 'android', req);
        return res.json({
            success: true,
            migrationStatus: outcome.status,
            token: rawToken,
            expiresAt,
            user: serializeUser(outcome.user)
        });
    } catch (err) {
        return next(err);
    }
});

module.exports = {
    router,
    serializeUser,
    applyDhakaMidnightResetIfNeeded
};
