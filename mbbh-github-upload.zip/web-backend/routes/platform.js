const express = require('express');
const db = require('../db/adapter');
const { requireAuth } = require('../middleware/auth');
const {
    VIP_PLANS,
    OFFICIAL_RECHARGE_NUMBERS,
    getDhakaDateStr,
    getDailyTracks,
    isValidBangladeshPhone
} = require('../config/plans');
const {
    generateSalt,
    hashPassword,
    verifyPasswordWithAlgo,
    generateId,
    CURRENT_ALGO
} = require('../security/crypto');
const { serializeUser, applyDhakaMidnightResetIfNeeded } = require('./auth');

const router = express.Router();

// GET /api/v1/platform/vip-plans (Public catalog)
router.get('/vip-plans', (_req, res) => {
    res.json({
        success: true,
        plans: VIP_PLANS,
        rechargeNumbers: OFFICIAL_RECHARGE_NUMBERS
    });
});

// GET /api/v1/platform/dashboard (Authenticated summary)
router.get('/dashboard', requireAuth, async (req, res, next) => {
    try {
        const userRow = await applyDhakaMidnightResetIfNeeded(req.auth.user);
        const today = getDhakaDateStr();

        const [txRes, completedRes, teamRes] = await Promise.all([
            db.query(
                `SELECT id, type, method, amount, balance_before, balance_after, trx_id, status, note, created_at
                 FROM transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`,
                [userRow.id]
            ),
            db.query(
                `SELECT track_id, rating, reward_amount FROM task_completions WHERE user_id = $1 AND task_date = $2`,
                [userRow.id, today]
            ),
            db.query(
                `SELECT r.tier, r.commission_earned, r.created_at, u.phone, u.vip_tier, u.total_recharged
                 FROM referrals r
                 JOIN users u ON u.id = r.invited_user_id
                 WHERE r.inviter_user_id = $1
                 ORDER BY r.created_at DESC`,
                [userRow.id]
            )
        ]);

        const completedMap = new Map(completedRes.rows.map((r) => [r.track_id, r]));
        const dailyTracks = getDailyTracks().map((t) => ({
            ...t,
            isCompleted: completedMap.has(t.id),
            userRating: completedMap.get(t.id)?.rating || 5
        }));

        const teamMembers = teamRes.rows.map((m) => ({
            phoneMasked: m.phone.slice(0, 3) + '****' + m.phone.slice(-4),
            tier: Number(m.tier),
            vipPlan: `VIP ${m.vip_tier}`,
            depositAmount: Number(m.total_recharged || 0),
            commissionEarned: Number(m.commission_earned || 0),
            createdAt: m.created_at
        }));

        const teamCounts = {
            tier1: teamMembers.filter((m) => m.tier === 1).length,
            tier2: teamMembers.filter((m) => m.tier === 2).length,
            tier3: teamMembers.filter((m) => m.tier === 3).length
        };

        return res.json({
            success: true,
            user: serializeUser(userRow),
            vipPlans: VIP_PLANS,
            rechargeNumbers: OFFICIAL_RECHARGE_NUMBERS,
            dailyTracks,
            transactions: txRes.rows.map((t) => ({
                id: t.id,
                type: t.type,
                method: t.method,
                amount: Number(t.amount),
                trxId: t.trx_id,
                status: t.status,
                note: t.note,
                createdAt: t.created_at
            })),
            teamCounts,
            teamMembers
        });
    } catch (err) {
        return next(err);
    }
});

// POST /api/v1/platform/tasks/complete
router.post('/tasks/complete', requireAuth, async (req, res, next) => {
    try {
        const trackId = String(req.body?.trackId || '').trim();
        const rating = Number(req.body?.rating || 5);
        const listenSeconds = Number(req.body?.listenSeconds || 0);
        const today = getDhakaDateStr();

        if (!trackId) {
            return res.status(400).json({ success: false, message: 'ট্র্যাক নির্বাচন করা হয়নি।', messageEn: 'Track ID is required.' });
        }
        if (rating < 1 || rating > 5) {
            return res.status(400).json({ success: false, message: '১ থেকে ৫ স্টার রেটিং দিন।', messageEn: 'Rating must be between 1 and 5.' });
        }
        if (listenSeconds < 12) {
            return res.status(400).json({ success: false, message: 'পুরস্কার পেতে কমপক্ষে ১২ সেকেন্ড গান শুনুন।', messageEn: 'Listen at least 12 seconds to unlock reward.' });
        }

        const dailyTracks = getDailyTracks();
        if (!dailyTracks.some((t) => t.id === trackId)) {
            return res.status(400).json({ success: false, message: 'অকার্যকর মিউজিক ট্র্যাক।', messageEn: 'Invalid track ID for today.' });
        }

        const result = await db.withTransaction(async (tx) => {
            const uRes = await tx.query(`SELECT * FROM users WHERE id = $1`, [req.auth.user.id]);
            const user = uRes.rows[0];
            if (Number(user.vip_tier) === 0 && Number(user.vip_expire_days) <= 0) {
                return { errorStatus: 403, message: 'ফ্রি ট্রায়ালের মেয়াদ শেষ! কাজ চালিয়ে যেতে ভিআইপি আপগ্রেড করুন।', messageEn: 'Free trial expired! Upgrade to VIP to continue.' };
            }

            const plan = VIP_PLANS.find((p) => p.tier === Number(user.vip_tier)) || VIP_PLANS[0];
            if (Number(user.completed_tasks_today) >= plan.dailyTasks) {
                return { errorStatus: 400, message: 'আজকের সকল টাস্ক সম্পন্ন হয়েছে!', messageEn: 'Daily task limit reached.' };
            }

            const dup = await tx.query(
                `SELECT id FROM task_completions WHERE user_id = $1 AND task_date = $2 AND track_id = $3`,
                [user.id, today, trackId]
            );
            if (dup.rows.length > 0) {
                return { errorStatus: 409, message: 'এই গানটির পুরস্কার ইতিমধ্যেই দাবি করা হয়েছে!', messageEn: 'Track already rewarded today.' };
            }

            const reward = Number(plan.rewardPerTask);
            const balanceBefore = Number(user.balance);
            const balanceAfter = Number((balanceBefore + reward).toFixed(2));
            const txId = generateId('TSK');
            const trxRef = `TASK_${today.replace(/-/g, '')}_${trackId}_${user.id.slice(-4)}_${Date.now().toString().slice(-4)}`;

            await tx.query(
                `INSERT INTO task_completions (id, user_id, task_date, track_id, rating, reward_amount)
                 VALUES ($1, $2, $3, $4, $5, $6)`,
                [generateId('TC'), user.id, today, trackId, Math.round(rating), reward]
            );

            await tx.query(
                `UPDATE users
                 SET balance = $1,
                     today_earnings = today_earnings + $2,
                     monthly_earnings = monthly_earnings + $2,
                     completed_tasks_today = completed_tasks_today + 1,
                     updated_at = $3
                 WHERE id = $4`,
                [balanceAfter, reward, new Date().toISOString(), user.id]
            );

            await tx.query(
                `INSERT INTO transactions (id, user_id, type, method, amount, balance_before, balance_after, trx_id, status, note)
                 VALUES ($1, $2, 'TASK_REWARD', 'Music Evaluation', $3, $4, $5, $6, 'SUCCESS', $7)`,
                [txId, user.id, reward, balanceBefore, balanceAfter, trxRef, `Rated ${trackId} (${rating} stars)`]
            );

            const refreshed = await tx.query(`SELECT * FROM users WHERE id = $1`, [user.id]);
            return { reward, user: refreshed.rows[0] };
        });

        if (result.errorStatus) {
            return res.status(result.errorStatus).json({
                success: false,
                message: result.message,
                messageEn: result.messageEn
            });
        }

        return res.json({
            success: true,
            reward: result.reward,
            message: `🎉 অভিনন্দন! আপনি ৳${result.reward.toFixed(2)} অর্জন করেছেন!`,
            messageEn: `🎉 Congratulations! You earned ৳${result.reward.toFixed(2)}!`,
            user: serializeUser(result.user)
        });
    } catch (err) {
        return next(err);
    }
});

// POST /api/v1/platform/wallet/bind
router.post('/wallet/bind', requireAuth, async (req, res, next) => {
    try {
        const walletType = String(req.body?.walletType || '').trim();
        const walletNumber = String(req.body?.walletNumber || '').trim();
        const accountName = String(req.body?.accountName || '').trim();
        const paymentPin = String(req.body?.paymentPin || '').trim();

        if (!['bKash', 'Nagad'].includes(walletType)) {
            return res.status(400).json({ success: false, message: 'বিকাশ বা নগদ নির্বাচন করুন।', messageEn: 'Select bKash or Nagad.' });
        }
        if (!isValidBangladeshPhone(walletNumber)) {
            return res.status(400).json({ success: false, message: 'সঠিক ১১-সংখ্যার ওয়ালেট নম্বর দিন।', messageEn: 'Enter a valid 11-digit wallet number.' });
        }
        if (!/^\d{6}$/.test(paymentPin)) {
            return res.status(400).json({ success: false, message: 'সঠিক ৬-সংখ্যার পেমেন্ট পিন দিন।', messageEn: 'Payment PIN must be exactly 6 digits.' });
        }

        const pinSalt = generateSalt(16);
        const pinHash = hashPassword(paymentPin, pinSalt);
        const safeName = accountName || `MBBH_${req.auth.user.phone.slice(-4)}`;

        await db.query(
            `UPDATE users
             SET bound_account_name = $1,
                 bound_wallet_type = $2,
                 bound_wallet_number = $3,
                 payment_pin_hash = $4,
                 payment_pin_salt = $5,
                 updated_at = $6
             WHERE id = $7`,
            [safeName.slice(0, 80), walletType, walletNumber, pinHash, pinSalt, new Date().toISOString(), req.auth.user.id]
        );

        const refreshed = await db.query(`SELECT * FROM users WHERE id = $1`, [req.auth.user.id]);
        return res.json({
            success: true,
            message: 'ওয়ালেট ও পেমেন্ট পিন সফলভাবে সংযুক্ত করা হয়েছে!',
            messageEn: 'Wallet & payment PIN bound successfully!',
            user: serializeUser(refreshed.rows[0])
        });
    } catch (err) {
        return next(err);
    }
});

// POST /api/v1/platform/recharge
// Strictly creates a PENDING verification request — NEVER credits balance without reconciliation.
router.post('/recharge', requireAuth, async (req, res, next) => {
    try {
        const method = String(req.body?.method || '').trim();
        const amount = Number(req.body?.amount || 0);
        const trxId = String(req.body?.trxId || '').trim().toUpperCase();

        if (!['bKash', 'Nagad'].includes(method)) {
            return res.status(400).json({ success: false, message: 'বিকাশ বা নগদ নির্বাচন করুন।', messageEn: 'Choose bKash or Nagad.' });
        }
        if (!Number.isFinite(amount) || amount < 850 || amount > 2500000) {
            return res.status(400).json({ success: false, message: 'রিচার্জের পরিমাণ ৳৮৫০ থেকে ৳২৫,০০,০০০ এর মধ্যে হতে হবে।', messageEn: 'Recharge amount must be between ৳850 and ৳2,500,000.' });
        }
        if (!/^[A-Z0-9]{8,24}$/.test(trxId)) {
            return res.status(400).json({ success: false, message: 'সঠিক ৮-২৪ অক্ষরের ট্রানজেকশন আইডি (TrxID) লিখুন।', messageEn: 'Enter a valid 8-24 character alphanumeric TrxID.' });
        }

        const outcome = await db.withTransaction(async (tx) => {
            const dup = await tx.query(`SELECT id FROM transactions WHERE trx_id = $1`, [trxId]);
            if (dup.rows.length > 0) {
                return { duplicate: true };
            }
            const uRes = await tx.query(`SELECT balance FROM users WHERE id = $1`, [req.auth.user.id]);
            const curBal = Number(uRes.rows[0].balance);

            const id = generateId('RCH');
            await tx.query(
                `INSERT INTO transactions (id, user_id, type, method, amount, balance_before, balance_after, trx_id, status, note)
                 VALUES ($1, $2, 'RECHARGE', $3, $4, $5, $5, $6, 'PENDING', 'Awaiting finance reconciliation')`,
                [id, req.auth.user.id, method, amount, curBal, trxId]
            );
            return { duplicate: false, id };
        });

        if (outcome.duplicate) {
            return res.status(409).json({
                success: false,
                message: 'এই ট্রানজেকশন আইডি (TrxID) ইতিপূর্বে ব্যবহার করা হয়েছে! ডুপ্লিকেট TrxID গ্রহণযোগ্য নয়।',
                messageEn: 'Duplicate TrxID rejected. This TrxID has already been submitted.'
            });
        }

        return res.status(201).json({
            success: true,
            message: 'রিচার্জ অনুরোধ গৃহীত (যাচাইকরণাধীন)। ফাইন্যান্স টিম স্টেটমেন্ট যাচাই করে ৫-১৫ মিনিটের মধ্যে ব্যালেন্স যুক্ত করবে।',
            messageEn: 'Recharge request submitted (Pending Verification). Balance will be credited after reconciliation.'
        });
    } catch (err) {
        return next(err);
    }
});

// POST /api/v1/platform/vip/upgrade
router.post('/vip/upgrade', requireAuth, async (req, res, next) => {
    try {
        const tier = Number(req.body?.tier);
        const plan = VIP_PLANS.find((p) => p.tier === tier);
        if (!plan || tier <= 0) {
            return res.status(400).json({ success: false, message: 'অকার্যকর ভিআইপি প্ল্যান।', messageEn: 'Invalid VIP tier.' });
        }

        const outcome = await db.withTransaction(async (tx) => {
            const uRes = await tx.query(`SELECT * FROM users WHERE id = $1`, [req.auth.user.id]);
            const user = uRes.rows[0];
            const balanceBefore = Number(user.balance);
            if (balanceBefore < plan.price) {
                return {
                    errorStatus: 400,
                    message: `পর্যাপ্ত ব্যালেন্স নেই! প্রয়োজন: ৳${plan.price}, বর্তমান ব্যালেন্স: ৳${balanceBefore.toFixed(2)}`,
                    messageEn: `Insufficient balance. Required: ৳${plan.price}, Current: ৳${balanceBefore.toFixed(2)}`
                };
            }
            const balanceAfter = Number((balanceBefore - plan.price).toFixed(2));
            await tx.query(
                `UPDATE users SET balance = $1, vip_tier = $2, vip_expire_days = 365, completed_tasks_today = 0, updated_at = $3 WHERE id = $4`,
                [balanceAfter, tier, new Date().toISOString(), user.id]
            );
            await tx.query(
                `INSERT INTO transactions (id, user_id, type, method, amount, balance_before, balance_after, trx_id, status, note)
                 VALUES ($1, $2, 'VIP_UPGRADE', $3, $4, $5, $6, $7, 'SUCCESS', '365-Day Contract Activated')`,
                [generateId('VIP'), user.id, `${plan.name} (${plan.codeName})`, plan.price, balanceBefore, balanceAfter, `VIP${tier}_${Date.now()}_${user.id.slice(-4)}`]
            );
            const refreshed = await tx.query(`SELECT * FROM users WHERE id = $1`, [user.id]);
            return { user: refreshed.rows[0] };
        });

        if (outcome.errorStatus) {
            return res.status(outcome.errorStatus).json({ success: false, message: outcome.message, messageEn: outcome.messageEn });
        }

        return res.json({
            success: true,
            message: `অভিনন্দন! সফলভাবে ${plan.name} (${plan.codeName})-এ আপগ্রেড করা হয়েছে! মেয়াদ ৩৬৫ দিন।`,
            messageEn: `Upgraded to ${plan.name} (${plan.codeName}) for 365 days!`,
            user: serializeUser(outcome.user)
        });
    } catch (err) {
        return next(err);
    }
});

// POST /api/v1/platform/withdraw
router.post('/withdraw', requireAuth, async (req, res, next) => {
    try {
        const amount = Number(req.body?.amount || 0);
        const paymentPin = String(req.body?.paymentPin || '').trim();

        if (!Number.isFinite(amount) || amount < 500 || amount > 2500000) {
            return res.status(400).json({ success: false, message: 'সর্বনিম্ন উত্তোলনের পরিমাণ ৳৫০০।', messageEn: 'Minimum withdrawal amount is ৳500.' });
        }
        if (!/^\d{6}$/.test(paymentPin)) {
            return res.status(400).json({ success: false, message: '৬-সংখ্যার পেমেন্ট পাসওয়ার্ড দিন।', messageEn: 'Enter your 6-digit payment PIN.' });
        }

        const outcome = await db.withTransaction(async (tx) => {
            const uRes = await tx.query(`SELECT * FROM users WHERE id = $1`, [req.auth.user.id]);
            const user = uRes.rows[0];
            if (!user.bound_wallet_number || !user.payment_pin_hash) {
                return { errorStatus: 400, message: 'প্রথমে বিকাশ/নগদ ওয়ালেট এবং পেমেন্ট পিন সেটআপ করুন!', messageEn: 'Please bind your withdrawal wallet and PIN first.' };
            }
            if (Number(user.vip_tier) === 0 && Number(user.vip_expire_days) <= 0) {
                return { errorStatus: 403, message: 'ফ্রি ট্রায়ালের মেয়াদ শেষ! উত্তোলন করতে ভিআইপি ১-এ আপগ্রেড করুন।', messageEn: 'Free trial expired! Upgrade to VIP 1 to withdraw.' };
            }
            const pinCheck = verifyPasswordWithAlgo(paymentPin, user.payment_pin_salt, user.payment_pin_hash, CURRENT_ALGO);
            if (!pinCheck.valid) {
                return { errorStatus: 401, message: 'ভুল পেমেন্ট পাসওয়ার্ড!', messageEn: 'Incorrect payment PIN.' };
            }
            const balanceBefore = Number(user.balance);
            if (balanceBefore < amount) {
                return { errorStatus: 400, message: `পর্যাপ্ত ব্যালেন্স নেই! বর্তমান ব্যালেন্স: ৳${balanceBefore.toFixed(2)}`, messageEn: `Insufficient balance: ৳${balanceBefore.toFixed(2)}` };
            }
            const balanceAfter = Number((balanceBefore - amount).toFixed(2));
            await tx.query(
                `UPDATE users SET balance = $1, total_withdrawn = total_withdrawn + $2, updated_at = $3 WHERE id = $4`,
                [balanceAfter, amount, new Date().toISOString(), user.id]
            );
            await tx.query(
                `INSERT INTO transactions (id, user_id, type, method, amount, balance_before, balance_after, trx_id, status, note)
                 VALUES ($1, $2, 'WITHDRAWAL', $3, $4, $5, $6, $7, 'PENDING', $8)`,
                [generateId('WD'), user.id, user.bound_wallet_type, amount, balanceBefore, balanceAfter, `WD_${Date.now()}_${user.id.slice(-4)}`, `To ${user.bound_wallet_number}`]
            );
            const refreshed = await tx.query(`SELECT * FROM users WHERE id = $1`, [user.id]);
            return { user: refreshed.rows[0] };
        });

        if (outcome.errorStatus) {
            return res.status(outcome.errorStatus).json({ success: false, message: outcome.message, messageEn: outcome.messageEn });
        }

        return res.status(201).json({
            success: true,
            message: 'উত্তোলন অনুরোধ সফলভাবে জমা দেওয়া হয়েছে! ২৪ ঘণ্টার মধ্যে বিকাশ/নগদে পাঠানো হবে।',
            messageEn: 'Withdrawal submitted successfully! Processing within 24 hours.',
            user: serializeUser(outcome.user)
        });
    } catch (err) {
        return next(err);
    }
});

module.exports = router;
