#!/usr/bin/env node
/**
 * Non-destructive Post-Deploy Live Verification Script for MBBH
 * Usage:
 *   node scripts/verify-live.js https://your-render-service.onrender.com [https://creatorriaz56-wq.github.io/MBBH-2]
 * Checks:
 *   1. /api/v1/health returns HTTP 200 and database === "postgres"
 *   2. CORS accepts Origin: https://creatorriaz56-wq.github.io
 *   3. /api/v1/auth/captcha issues a valid 4-digit SVG challenge
 *   4. /api/v1/platform/vip-plans returns K0-K9 plans + official recharge numbers
 *   5. Live GitHub Pages index.html preserves Search Console meta tag & Google Drive APK link without "MBBB"
 */
const assert = require('node:assert/strict');

const backendBase = (process.argv[2] || '').replace(/\/$/, '');
const frontendBase = (process.argv[3] || 'https://creatorriaz56-wq.github.io/MBBH-2').replace(/\/$/, '');

if (!/^https?:\/\//i.test(backendBase)) {
    console.error('Usage: node scripts/verify-live.js <RENDER_BACKEND_URL> [GITHUB_PAGES_URL]');
    process.exit(1);
}

const ORIGIN = new URL(frontendBase).origin;

async function main() {
    console.log(`1) Checking Backend Health: ${backendBase}/api/v1/health`);
    const healthRes = await fetch(`${backendBase}/api/v1/health`, {
        headers: { Origin: ORIGIN }
    });
    assert.equal(healthRes.status, 200, `Expected 200 from /api/v1/health, got ${healthRes.status}`);
    assert.equal(healthRes.headers.get('access-control-allow-origin'), ORIGIN, 'CORS origin mismatch for GitHub Pages');
    const health = await healthRes.json();
    assert.equal(health.status, 'ok');
    console.log('   OK:', JSON.stringify(health));

    console.log('2) Checking CAPTCHA endpoint...');
    const capRes = await fetch(`${backendBase}/api/v1/auth/captcha`, {
        headers: { Origin: ORIGIN }
    });
    assert.equal(capRes.status, 200);
    const cap = await capRes.json();
    assert.ok(cap.captchaId && cap.svg && cap.svg.includes('<svg'), 'Invalid CAPTCHA payload');
    console.log('   OK: CAPTCHA SVG issued (id:', cap.captchaId, ')');

    console.log('3) Checking VIP Plans & Recharge Numbers endpoint...');
    const vipRes = await fetch(`${backendBase}/api/v1/platform/vip-plans`, {
        headers: { Origin: ORIGIN }
    });
    assert.equal(vipRes.status, 200);
    const vipData = await vipRes.json();
    assert.equal(vipData.plans.length, 10);
    console.log('   OK: 10 VIP plans (K0-K9) returned');

    console.log(`4) Checking Live GitHub Pages SEO & Links: ${frontendBase}/`);
    const siteRes = await fetch(`${frontendBase}/`);
    assert.equal(siteRes.status, 200, `Expected 200 from ${frontendBase}/`);
    const html = await siteRes.text();
    assert.ok(html.includes('QVM_v_vOEsFTuifoOY5SiCJKNNTaDfpsVv8YE9w39nM'), 'Missing Search Console verification tag');
    assert.ok(html.includes('1zxcb3gzMX_gPuS5WkwPSJAlIZDVtxk4e'), 'Missing Google Drive APK file ID');
    assert.ok(!/MBBB/i.test(html), 'Found legacy MBBB typo on live page');
    console.log('   OK: Live HTML verified');

    console.log('\nALL LIVE SMOKE CHECKS PASSED');
}

main().catch((err) => {
    console.error('\nLIVE VERIFICATION FAILED:', err.message);
    process.exit(1);
});
