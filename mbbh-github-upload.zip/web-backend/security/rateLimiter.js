const db = require('../db/adapter');
const { generateId } = require('./crypto');

// In-memory fast cache + persistent DB audit fallback
const loginAttempts = new Map();
const MAX_FAILED_ATTEMPTS = 5;
const LOCK_DURATION_MS = 60 * 1000; // 60 seconds

function checkLoginRateLimit(phone, ipAddress = '') {
    const key = `${phone}|${ipAddress}`;
    const now = Date.now();
    const entry = loginAttempts.get(key);
    if (entry && entry.lockedUntil > now) {
        const remainingSeconds = Math.max(1, Math.ceil((entry.lockedUntil - now) / 1000));
        return {
            allowed: false,
            remainingSeconds
        };
    }
    if (entry && entry.lockedUntil && entry.lockedUntil <= now) {
        loginAttempts.delete(key);
    }
    return { allowed: true, remainingSeconds: 0 };
}

async function recordAuthEvent({ phone, action, success, ipAddress = '', detail = '' }) {
    const key = `${phone}|${ipAddress}`;
    if (action === 'login') {
        if (success) {
            loginAttempts.delete(key);
        } else {
            const cur = loginAttempts.get(key) || { count: 0, lockedUntil: 0 };
            cur.count += 1;
            if (cur.count >= MAX_FAILED_ATTEMPTS) {
                cur.lockedUntil = Date.now() + LOCK_DURATION_MS;
                cur.count = 0;
            }
            loginAttempts.set(key, cur);
        }
    }

    try {
        await db.query(
            `INSERT INTO auth_audit_logs (id, phone, action, success, ip_address, detail) VALUES ($1, $2, $3, $4, $5, $6)`,
            [generateId('AUD'), String(phone || '').slice(0, 16), action, Boolean(success), String(ipAddress || '').slice(0, 64), String(detail || '').slice(0, 200)]
        );
    } catch {
        // Never crash auth path if audit insert fails
    }
}

function clearRateLimitForTests() {
    loginAttempts.clear();
}

module.exports = {
    checkLoginRateLimit,
    recordAuthEvent,
    clearRateLimitForTests
};
