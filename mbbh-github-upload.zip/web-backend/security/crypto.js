const crypto = require('crypto');

const CURRENT_ALGO = 'pbkdf2_100k_64';
const ITERATIONS_CURRENT = 100000;
const KEYLEN_CURRENT = 64;

function generateSalt(bytes = 16) {
    return crypto.randomBytes(bytes).toString('hex');
}

function hashPassword(password, salt) {
    return crypto.pbkdf2Sync(password, salt, ITERATIONS_CURRENT, KEYLEN_CURRENT, 'sha256').toString('hex');
}

// Legacy compatibility: server.js v1 used pbkdf2 10000 iterations, 32 bytes
function hashLegacyServerJs(password, salt) {
    return crypto.pbkdf2Sync(password, salt, 10000, 32, 'sha256').toString('hex');
}

// Legacy compatibility: Android SecurityUtils.kt used SHA-256("$salt:$password:MBBH_SECURE_SALT_2026")
function hashLegacyAndroidSha256(password, salt) {
    return crypto.createHash('sha256').update(`${salt}:${password}:MBBH_SECURE_SALT_2026`, 'utf8').digest('hex');
}

function timingSafeHexEqual(a, b) {
    if (!a || !b || a.length !== b.length) return false;
    try {
        const bufA = Buffer.from(a, 'hex');
        const bufB = Buffer.from(b, 'hex');
        if (bufA.length !== bufB.length) return false;
        return crypto.timingSafeEqual(bufA, bufB);
    } catch {
        return false;
    }
}

function verifyPasswordWithAlgo(password, salt, expectedHash, algo = CURRENT_ALGO) {
    if (!password || !salt || !expectedHash) return { valid: false, needsRehash: false };
    let computed;
    let needsRehash = false;
    if (algo === CURRENT_ALGO) {
        computed = hashPassword(password, salt);
    } else if (algo === 'pbkdf2_10k_32') {
        computed = hashLegacyServerJs(password, salt);
        needsRehash = true;
    } else if (algo === 'android_sha256_2026') {
        computed = hashLegacyAndroidSha256(password, salt);
        needsRehash = true;
    } else {
        return { valid: false, needsRehash: false };
    }
    return {
        valid: timingSafeHexEqual(computed, expectedHash),
        needsRehash
    };
}

function generateSessionToken() {
    return crypto.randomBytes(32).toString('hex');
}

function hashToken(rawToken) {
    const pepper = process.env.SESSION_SECRET || 'mbbh-local-dev-secret-change-in-production';
    return crypto.createHmac('sha256', pepper).update(String(rawToken)).digest('hex');
}

function generateId(prefix = 'ID') {
    return `${prefix}_${crypto.randomBytes(8).toString('hex')}`;
}

function generateReferralCode() {
    const alphabet = '23456789abcdefghjkmnpqrstuvwxyz';
    let code = '';
    const bytes = crypto.randomBytes(8);
    for (let i = 0; i < 8; i++) {
        code += alphabet[bytes[i] % alphabet.length];
    }
    return code;
}

function generateUid() {
    const num = crypto.randomInt(100000, 999999);
    return `MBBH_${num}_${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
}

module.exports = {
    CURRENT_ALGO,
    generateSalt,
    hashPassword,
    hashLegacyAndroidSha256,
    verifyPasswordWithAlgo,
    generateSessionToken,
    hashToken,
    generateId,
    generateReferralCode,
    generateUid,
    timingSafeHexEqual
};
