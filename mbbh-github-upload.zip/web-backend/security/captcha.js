const crypto = require('crypto');
const db = require('../db/adapter');
const { generateSalt, generateId, timingSafeHexEqual } = require('./crypto');

const CAPTCHA_TTL_MS = 3 * 60 * 1000; // 3 minutes

function hashCaptchaAnswer(answer, salt) {
    return crypto.createHash('sha256').update(`${salt}:${String(answer).trim()}`).digest('hex');
}

function renderSvgCaptcha(code) {
    const chars = code.split('');
    const noiseLines = Array.from({ length: 4 }, (_, idx) => {
        const y1 = crypto.randomInt(6, 38);
        const y2 = crypto.randomInt(6, 38);
        const opacity = (0.25 + idx * 0.08).toFixed(2);
        return `<line x1="0" y1="${y1}" x2="132" y2="${y2}" stroke="#E5A93C" stroke-width="1.2" opacity="${opacity}" />`;
    }).join('');

    const charNodes = chars.map((ch, i) => {
        const x = 18 + i * 26 + crypto.randomInt(-2, 3);
        const y = 30 + crypto.randomInt(-3, 4);
        const rot = crypto.randomInt(-14, 15);
        return `<text x="${x}" y="${y}" transform="rotate(${rot} ${x} ${y})" fill="#FFD700" font-family="monospace" font-size="24" font-weight="900">${ch}</text>`;
    }).join('');

    return `<svg xmlns="http://www.w3.org/2000/svg" width="132" height="44" viewBox="0 0 132 44" role="img" aria-label="Security CAPTCHA">
  <defs>
    <linearGradient id="capBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1E2430"/>
      <stop offset="100%" stop-color="#11151C"/>
    </linearGradient>
  </defs>
  <rect width="132" height="44" rx="8" fill="url(#capBg)" stroke="#E5A93C" stroke-width="1.2"/>
  ${noiseLines}
  ${charNodes}
</svg>`;
}

async function createCaptcha(ipAddress = '') {
    const code = String(crypto.randomInt(1000, 10000));
    const salt = generateSalt(8);
    const answerHash = hashCaptchaAnswer(code, salt);
    const id = generateId('CAP');
    const expiresAt = new Date(Date.now() + CAPTCHA_TTL_MS).toISOString();

    await db.query(
        `INSERT INTO captchas (id, answer_hash, salt, ip_address, expires_at) VALUES ($1, $2, $3, $4, $5)`,
        [id, answerHash, salt, ipAddress.slice(0, 64), expiresAt]
    );

    // Opportunistic cleanup of expired captchas
    await db.query(`DELETE FROM captchas WHERE expires_at < $1`, [new Date(Date.now() - 3600000).toISOString()]);

    return {
        captchaId: id,
        svg: renderSvgCaptcha(code),
        expiresInSeconds: Math.floor(CAPTCHA_TTL_MS / 1000)
    };
}

/**
 * Single-use atomic CAPTCHA consumption & verification.
 * Consumes the challenge on attempt so replay/brute-forcing one captchaId fails.
 */
async function verifyAndConsumeCaptcha(captchaId, captchaInput) {
    const cleanId = (captchaId || '').trim();
    const cleanInput = (captchaInput || '').trim();
    if (!cleanId || !/^\d{4}$/.test(cleanInput)) {
        return { valid: false, messageBn: 'সঠিক ৪-সংখ্যার ক্যাপচা কোড দিন।', messageEn: 'Please enter a valid 4-digit CAPTCHA code.' };
    }

    return db.withTransaction(async (tx) => {
        const res = await tx.query(
            `SELECT id, answer_hash, salt, expires_at, consumed_at FROM captchas WHERE id = $1`,
            [cleanId]
        );
        if (res.rows.length === 0) {
            return { valid: false, messageBn: 'ক্যাপচা খুঁজে পাওয়া যায়নি! নতুন ক্যাপচা লোড করুন।', messageEn: 'CAPTCHA not found. Please refresh and try again.' };
        }
        const row = res.rows[0];
        if (row.consumed_at) {
            return { valid: false, messageBn: 'এই ক্যাপচা ইতিমধ্যেই ব্যবহার হয়েছে! নতুন ক্যাপচা নিন।', messageEn: 'This CAPTCHA has already been used. Please refresh.' };
        }
        // Mark consumed immediately to prevent replay even on wrong guess
        const nowIso = new Date().toISOString();
        await tx.query(`UPDATE captchas SET consumed_at = $1 WHERE id = $2`, [nowIso, cleanId]);

        if (new Date(row.expires_at).getTime() < Date.now()) {
            return { valid: false, messageBn: 'ক্যাপচার মেয়াদ শেষ! অনুগ্রহ করে নতুন ক্যাপচা দিন।', messageEn: 'CAPTCHA expired. Please refresh and try again.' };
        }

        const expected = hashCaptchaAnswer(cleanInput, row.salt);
        if (!timingSafeHexEqual(expected, row.answer_hash)) {
            return { valid: false, messageBn: 'ভুল ক্যাপচা কোড! নতুন ক্যাপচা দেখে পুনরায় চেষ্টা করুন।', messageEn: 'Incorrect CAPTCHA code! Please refresh and retry.' };
        }

        return { valid: true };
    });
}

module.exports = {
    createCaptcha,
    verifyAndConsumeCaptcha
};
