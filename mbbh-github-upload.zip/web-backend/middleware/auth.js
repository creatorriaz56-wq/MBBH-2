const db = require('../db/adapter');
const { hashToken } = require('../security/crypto');

const SESSION_COOKIE_NAME = 'mbbh_session';
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

function parseCookies(cookieHeader = '') {
    const out = {};
    if (!cookieHeader) return out;
    cookieHeader.split(';').forEach((part) => {
        const idx = part.indexOf('=');
        if (idx > 0) {
            const k = part.slice(0, idx).trim();
            const v = decodeURIComponent(part.slice(idx + 1).trim());
            out[k] = v;
        }
    });
    return out;
}

function extractRawToken(req) {
    const authHeader = req.headers.authorization || '';
    if (authHeader.startsWith('Bearer ')) {
        return authHeader.slice(7).trim();
    }
    const cookies = parseCookies(req.headers.cookie || '');
    return cookies[SESSION_COOKIE_NAME] || null;
}

function buildCookieOptions(req) {
    const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https' || process.env.NODE_ENV === 'production';
    return {
        httpOnly: true,
        secure: Boolean(isHttps),
        sameSite: isHttps ? 'none' : 'lax',
        path: '/',
        maxAge: SESSION_TTL_MS
    };
}

async function requireAuth(req, res, next) {
    try {
        const rawToken = extractRawToken(req);
        if (!rawToken) {
            return res.status(401).json({
                success: false,
                code: 'UNAUTHORIZED',
                message: 'সেশন পাওয়া যায়নি বা মেয়াদ শেষ হয়েছে! অনুগ্রহ করে পুনরায় লগইন করুন।',
                messageEn: 'Session missing or expired. Please log in again.'
            });
        }

        const tokenHash = hashToken(rawToken);
        const sessionRes = await db.query(
            `SELECT s.id AS session_id, s.user_id, s.expires_at, s.revoked_at,
                    u.id, u.phone, u.operator, u.name, u.balance, u.personal_wallet_balance,
                    u.vip_tier, u.vip_expire_days, u.referral_code, u.referred_by,
                    u.bound_account_name, u.bound_wallet_type, u.bound_wallet_number,
                    u.payment_pin_hash, u.today_earnings, u.yesterday_earnings, u.monthly_earnings,
                    u.referral_income, u.team_commission, u.total_recharged, u.total_withdrawn,
                    u.completed_tasks_today, u.last_task_reset_date, u.registration_date, u.account_origin
             FROM sessions s
             JOIN users u ON u.id = s.user_id
             WHERE s.token_hash = $1`,
            [tokenHash]
        );

        if (sessionRes.rows.length === 0) {
            return res.status(401).json({
                success: false,
                code: 'INVALID_SESSION',
                message: 'অবৈধ সেশন! পুনরায় লগইন করুন।',
                messageEn: 'Invalid session. Please log in again.'
            });
        }

        const row = sessionRes.rows[0];
        if (row.revoked_at || new Date(row.expires_at).getTime() <= Date.now()) {
            return res.status(401).json({
                success: false,
                code: 'SESSION_EXPIRED',
                message: 'আপনার লগইন সেশনের মেয়াদ শেষ হয়েছে! পুনরায় লগইন করুন।',
                messageEn: 'Your login session has expired. Please log in again.'
            });
        }

        req.auth = {
            sessionId: row.session_id,
            tokenHash,
            user: row
        };
        return next();
    } catch (err) {
        return next(err);
    }
}

module.exports = {
    SESSION_COOKIE_NAME,
    SESSION_TTL_MS,
    buildCookieOptions,
    extractRawToken,
    requireAuth
};
