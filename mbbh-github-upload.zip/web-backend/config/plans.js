// Authoritative Platform Configuration synchronized with verified MBBH Android models

const VIP_PLANS = [
    { tier: 0, name: 'Free Practicante', codeName: 'Internship', price: 0, dailyTasks: 4, rewardPerTask: 20, dailyIncome: 80, validity: '2 Days Free Internship', validityDays: 2, badgeColor: '#9E9E9E' },
    { tier: 1, name: 'VIP 1', codeName: 'K1', price: 1200, dailyTasks: 6, rewardPerTask: 10, dailyIncome: 60, validity: '1 Year (365 Days)', validityDays: 365, badgeColor: '#CD7F32' },
    { tier: 2, name: 'VIP 2', codeName: 'K2', price: 3500, dailyTasks: 10, rewardPerTask: 18, dailyIncome: 180, validity: '1 Year (365 Days)', validityDays: 365, badgeColor: '#C0C0C0' },
    { tier: 3, name: 'VIP 3', codeName: 'K3', price: 8500, dailyTasks: 16, rewardPerTask: 30, dailyIncome: 480, validity: '1 Year (365 Days)', validityDays: 365, badgeColor: '#FFD700' },
    { tier: 4, name: 'VIP 4', codeName: 'K4', price: 22000, dailyTasks: 25, rewardPerTask: 50, dailyIncome: 1250, validity: '1 Year (365 Days)', validityDays: 365, badgeColor: '#00E5FF' },
    { tier: 5, name: 'VIP 5', codeName: 'K5', price: 55000, dailyTasks: 35, rewardPerTask: 90, dailyIncome: 3150, validity: '1 Year (365 Days)', validityDays: 365, badgeColor: '#E040FB' },
    { tier: 6, name: 'VIP 6', codeName: 'K6', price: 130000, dailyTasks: 50, rewardPerTask: 150, dailyIncome: 7500, validity: '1 Year (365 Days)', validityDays: 365, badgeColor: '#FF5252' },
    { tier: 7, name: 'VIP 7', codeName: 'K7', price: 320000, dailyTasks: 75, rewardPerTask: 250, dailyIncome: 18750, validity: '1 Year (365 Days)', validityDays: 365, badgeColor: '#FFAB00' },
    { tier: 8, name: 'VIP 8', codeName: 'K8', price: 750000, dailyTasks: 110, rewardPerTask: 420, dailyIncome: 46200, validity: '1 Year (365 Days)', validityDays: 365, badgeColor: '#76FF03' },
    { tier: 9, name: 'VIP 9', codeName: 'K9', price: 1800000, dailyTasks: 160, rewardPerTask: 750, dailyIncome: 120000, validity: '1 Year (365 Days)', validityDays: 365, badgeColor: '#FF6D00' }
];

const OFFICIAL_RECHARGE_NUMBERS = {
    bKash: '01349988959',
    Nagad: '01336656008'
};

const TRACK_SETS = [
    [
        { id: 'm1', title: 'Sweet Friend-in my imagination', artist: 'MBBH Global Soundlab', genre: 'Acoustic Pop Symphony', views: '100,000', freq: 261.63 },
        { id: 'm2', title: 'Teddy Swims-Lose Control', artist: 'Teddy Swims (MBBH Mix)', genre: 'Soul Pop R&B', views: '180,000', freq: 293.66 },
        { id: 'm3', title: 'Matilda-Illusion', artist: 'Matilda UK Studio', genre: 'Electropop Rhythm', views: '150,000', freq: 329.63 },
        { id: 'm4', title: 'Celestial Waves (MBBH Global Mix)', artist: 'London Symphonic x MBBH', genre: 'Modern Electro-Acoustic', views: '240,000', freq: 349.23 }
    ],
    [
        { id: 'm1', title: 'Golden Melodic Synthwave', artist: 'Aura Beats UK', genre: 'Neon Synthwave Pop', views: '120,000', freq: 392.00 },
        { id: 'm2', title: 'Bengali Folk Fusion 2026', artist: 'Dhaka Underground Collective', genre: 'Acoustic Folk Beats', views: '310,000', freq: 440.00 },
        { id: 'm3', title: 'Upbeat Dance Anthem', artist: 'Southbank Soundlab', genre: 'EDM Dance Rhythm', views: '220,000', freq: 493.88 },
        { id: 'm4', title: 'Lo-Fi Piano Sunset', artist: 'Nordic Harmony', genre: 'Chill Lo-Fi Sunset', views: '195,000', freq: 523.25 }
    ],
    [
        { id: 'm1', title: 'Velvet Soul Rhythm', artist: 'MBBH Global Soundlab', genre: 'Soul & Melody Fusion', views: '280,000', freq: 293.66 },
        { id: 'm2', title: 'Neon Nights London', artist: 'London Symphonic x MBBH', genre: 'Urban Electro Groove', views: '165,000', freq: 349.23 },
        { id: 'm3', title: 'Dhaka Midnight Rain', artist: 'Dhaka Underground Collective', genre: 'Bengali Fusion Pop', views: '340,000', freq: 440.00 },
        { id: 'm4', title: 'Echoes of Eternity', artist: 'Nordic Harmony', genre: 'Cinematic Ambient', views: '125,000', freq: 523.25 }
    ],
    [
        { id: 'm1', title: 'Sunrise Electro Anthem', artist: 'Southbank Soundlab', genre: 'High Energy Pop', views: '210,000', freq: 329.63 },
        { id: 'm2', title: 'Golden Horizon Beat', artist: 'Aura Beats UK', genre: 'Deep Chillwave', views: '175,000', freq: 392.00 },
        { id: 'm3', title: 'Matilda-Illusion (VIP Mix)', artist: 'Matilda UK Studio', genre: 'Electropop Rhythm', views: '190,000', freq: 440.00 },
        { id: 'm4', title: 'Lo-Fi Acoustic Breeze', artist: 'Nordic Harmony', genre: 'Acoustic Melody', views: '140,000', freq: 493.88 }
    ]
];

function getDhakaDateStr(date = new Date()) {
    return new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Dhaka',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    }).format(date);
}

function getDailyTracks() {
    const now = new Date();
    const dhakaStr = getDhakaDateStr(now);
    const [y, m, d] = dhakaStr.split('-').map(Number);
    const dayIndex = Math.floor(Date.UTC(y, m - 1, d) / 86400000);
    const rotation = ((dayIndex % 4) + 4) % 4;
    return TRACK_SETS[rotation];
}

function isValidBangladeshPhone(phone) {
    return /^01[3-9]\d{8}$/.test((phone || '').trim());
}

function getBangladeshOperator(phone) {
    const clean = (phone || '').replace(/\D/g, '');
    if (clean.length < 3) return null;
    switch (clean.slice(0, 3)) {
        case '017':
        case '013':
            return 'Grameenphone';
        case '018':
            return 'Robi';
        case '019':
        case '014':
            return 'Banglalink';
        case '016':
            return 'Airtel';
        case '015':
            return 'Teletalk';
        default:
            return null;
    }
}

module.exports = {
    VIP_PLANS,
    OFFICIAL_RECHARGE_NUMBERS,
    getDhakaDateStr,
    getDailyTracks,
    isValidBangladeshPhone,
    getBangladeshOperator
};
