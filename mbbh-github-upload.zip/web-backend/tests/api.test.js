const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');

const testDbPath = path.join(__dirname, '..', 'data', 'test_suite.sqlite');
if (fs.existsSync(testDbPath)) fs.unlinkSync(testDbPath);
process.env.SQLITE_PATH = testDbPath;
process.env.DATABASE_URL = '';
process.env.NODE_ENV = 'test';
process.env.ALLOWED_ORIGINS = 'https://creatorriaz56-wq.github.io,http://localhost:4000';

const db = require('../db/adapter');
const { createApp } = require('../server');
const { clearRateLimitForTests } = require('../security/rateLimiter');

let server;
let baseUrl;

function extractCaptchaCodeFromSvg(svg) {
    const matches = [...svg.matchAll(/<text[^>]*>(\d)<\/text>/g)];
    return matches.map((m) => m[1]).join('');
}

async function jsonReq(method, pathname, { body, cookie, origin, bearer } = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (cookie) headers.Cookie = cookie;
    if (origin) headers.Origin = origin;
    if (bearer) headers.Authorization = `Bearer ${bearer}`;

    const res = await fetch(`${baseUrl}${pathname}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined
    });
    const setCookie = res.headers.get('set-cookie');
    const data = await res.json();
    return { status: res.status, data, setCookie, headers: res.headers };
}

test.before(async () => {
    await db.initDb({ sqlitePath: testDbPath });
    const app = createApp({ serveStaticFrontend: false });
    server = http.createServer(app);
    await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
    const addr = server.address();
    baseUrl = `http://127.0.0.1:${addr.port}`;
});

test.after(async () => {
    if (server) await new Promise((resolve) => server.close(resolve));
    await db.closeDb();
    if (fs.existsSync(testDbPath)) fs.unlinkSync(testDbPath);
});

test('1. Health check reports ok', async () => {
    const res = await jsonReq('GET', '/api/v1/health');
    assert.equal(res.status, 200);
    assert.equal(res.data.status, 'ok');
    assert.equal(res.data.database, 'sqlite');
});

test('2. CORS blocks untrusted origins and allows GitHub Pages origin', async () => {
    const blocked = await jsonReq('GET', '/api/v1/health', { origin: 'https://evil-site.example' });
    assert.equal(blocked.status, 403);

    const allowed = await jsonReq('GET', '/api/v1/health', { origin: 'https://creatorriaz56-wq.github.io' });
    assert.equal(allowed.status, 200);
    assert.equal(allowed.headers.get('access-control-allow-origin'), 'https://creatorriaz56-wq.github.io');
});

test('3. Registration rejects invalid BD phone, password mismatch, wrong CAPTCHA, and prevents CAPTCHA replay', async () => {
    const cap = await jsonReq('GET', '/api/v1/auth/captcha');
    assert.equal(cap.status, 200);
    const code = extractCaptchaCodeFromSvg(cap.data.svg);
    assert.match(code, /^\d{4}$/);

    // Invalid phone (012 prefix)
    const badPhone = await jsonReq('POST', '/api/v1/auth/register', {
        body: { phone: '01234567890', password: 'secret123', confirmPassword: 'secret123', captchaId: cap.data.captchaId, captcha: code }
    });
    assert.equal(badPhone.status, 400);

    // Wrong CAPTCHA attempt consumes captchaId
    const badCap = await jsonReq('POST', '/api/v1/auth/register', {
        body: { phone: '01712345678', password: 'secret123', confirmPassword: 'secret123', captchaId: cap.data.captchaId, captcha: '0000' }
    });
    assert.equal(badCap.status, 400);

    // Replay same captchaId with correct code must be rejected!
    const replayCap = await jsonReq('POST', '/api/v1/auth/register', {
        body: { phone: '01712345678', password: 'secret123', confirmPassword: 'secret123', captchaId: cap.data.captchaId, captcha: code }
    });
    assert.equal(replayCap.status, 400);
});

test('4. Full Registration, Duplicate Rejection (409), Session Cookie Auth, Dashboard, Recharge TrxID Dedupe, Wallet Bind & Logout Revocation', async () => {
    // Register
    const cap1 = await jsonReq('GET', '/api/v1/auth/captcha');
    const code1 = extractCaptchaCodeFromSvg(cap1.data.svg);
    const reg = await jsonReq('POST', '/api/v1/auth/register', {
        body: { phone: '01799887766', password: 'mbbhPass123', confirmPassword: 'mbbhPass123', referralCode: '892341', captchaId: cap1.data.captchaId, captcha: code1 }
    });
    assert.equal(reg.status, 201);
    assert.equal(reg.data.success, true);
    assert.equal(reg.data.user.balance, 0);
    assert.equal(reg.data.user.operator, 'Grameenphone');
    assert.ok(reg.setCookie && reg.setCookie.includes('mbbh_session='));
    assert.ok(reg.setCookie.includes('HttpOnly'));
    const sessionCookie = reg.setCookie.split(';')[0];

    // Duplicate registration must fail with 409
    const cap2 = await jsonReq('GET', '/api/v1/auth/captcha');
    const code2 = extractCaptchaCodeFromSvg(cap2.data.svg);
    const dup = await jsonReq('POST', '/api/v1/auth/register', {
        body: { phone: '01799887766', password: 'mbbhPass123', confirmPassword: 'mbbhPass123', captchaId: cap2.data.captchaId, captcha: code2 }
    });
    assert.equal(dup.status, 409);

    // Session cookie works on /auth/me & /platform/dashboard
    const me = await jsonReq('GET', '/api/v1/auth/me', { cookie: sessionCookie });
    assert.equal(me.status, 200);
    assert.equal(me.data.user.phone, '01799887766');

    // Complete 1 music task (12s check enforced)
    const tooFastTask = await jsonReq('POST', '/api/v1/platform/tasks/complete', {
        cookie: sessionCookie,
        body: { trackId: 'm1', rating: 5, listenSeconds: 5 }
    });
    assert.equal(tooFastTask.status, 400);

    const validTask = await jsonReq('POST', '/api/v1/platform/tasks/complete', {
        cookie: sessionCookie,
        body: { trackId: 'm1', rating: 5, listenSeconds: 15 }
    });
    assert.equal(validTask.status, 200);
    assert.equal(validTask.data.user.balance, 20);

    // Recharge stays PENDING (balance unchanged) & duplicate TrxID rejected (409)
    const rch = await jsonReq('POST', '/api/v1/platform/recharge', {
        cookie: sessionCookie,
        body: { method: 'bKash', amount: 1200, trxId: 'BK12345678' }
    });
    assert.equal(rch.status, 201);

    const rchDup = await jsonReq('POST', '/api/v1/platform/recharge', {
        cookie: sessionCookie,
        body: { method: 'bKash', amount: 1200, trxId: 'BK12345678' }
    });
    assert.equal(rchDup.status, 409);

    // Wallet bind + PIN
    const bind = await jsonReq('POST', '/api/v1/platform/wallet/bind', {
        cookie: sessionCookie,
        body: { walletType: 'bKash', walletNumber: '01799887766', accountName: 'Test User', paymentPin: '123456' }
    });
    assert.equal(bind.status, 200);
    assert.equal(bind.data.user.hasPaymentPin, true);

    // Logout revokes session
    const logout = await jsonReq('POST', '/api/v1/auth/logout', { cookie: sessionCookie });
    assert.equal(logout.status, 200);

    const afterLogout = await jsonReq('GET', '/api/v1/auth/me', { cookie: sessionCookie });
    assert.equal(afterLogout.status, 401);
});

test('5. Login rate limiting triggers 429 after 5 failed attempts & Bearer login works', async () => {
    clearRateLimitForTests();
    for (let i = 0; i < 5; i++) {
        const cap = await jsonReq('GET', '/api/v1/auth/captcha');
        const code = extractCaptchaCodeFromSvg(cap.data.svg);
        const fail = await jsonReq('POST', '/api/v1/auth/login', {
            body: { phone: '01799887766', password: 'wrongPassword', captchaId: cap.data.captchaId, captcha: code }
        });
        assert.equal(fail.status, 401);
    }

    const capLocked = await jsonReq('GET', '/api/v1/auth/captcha');
    const codeLocked = extractCaptchaCodeFromSvg(capLocked.data.svg);
    const locked = await jsonReq('POST', '/api/v1/auth/login', {
        body: { phone: '01799887766', password: 'mbbhPass123', captchaId: capLocked.data.captchaId, captcha: codeLocked }
    });
    assert.equal(locked.status, 429);

    clearRateLimitForTests();
    const capOk = await jsonReq('GET', '/api/v1/auth/captcha');
    const codeOk = extractCaptchaCodeFromSvg(capOk.data.svg);
    const okLogin = await jsonReq('POST', '/api/v1/auth/login', {
        body: { phone: '01799887766', password: 'mbbhPass123', captchaId: capOk.data.captchaId, captcha: codeOk, clientType: 'android' }
    });
    assert.equal(okLogin.status, 200);
    assert.ok(okLogin.data.token);
});

test('6. Legacy Android SHA-256 account migration preserves balance & flags conflicts safely', async () => {
    const salt = 'a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4';
    const rawPass = 'legacyPass99';
    const legacyHash = crypto.createHash('sha256').update(`${salt}:${rawPass}:MBBH_SECURE_SALT_2026`).digest('hex');

    // Fresh phone migrates cleanly preserving exact balance 1450.50
    const mig = await jsonReq('POST', '/api/v1/auth/migrate-legacy', {
        body: {
            phone: '01811223344',
            password: rawPass,
            legacyPasswordHash: legacyHash,
            legacyPasswordSalt: salt,
            snapshot: {
                id: 'MBBH_551234',
                balance: 1450.5,
                vipTier: 1,
                vipExpireDays: 320,
                referralCode: 'legref12',
                transactions: [{ type: 'RECHARGE', method: 'bKash', amount: 1200, trxId: 'LEGTRX991', status: 'SUCCESS' }]
            }
        }
    });
    assert.equal(mig.status, 200);
    assert.equal(mig.data.migrationStatus, 'migrated');
    assert.equal(mig.data.user.balance, 1450.5);

    // Re-migrating an already-existing phone with different balance does NOT overwrite balance!
    const migConflict = await jsonReq('POST', '/api/v1/auth/migrate-legacy', {
        body: {
            phone: '01811223344',
            password: rawPass,
            legacyPasswordHash: legacyHash,
            legacyPasswordSalt: salt,
            snapshot: { balance: 999999 }
        }
    });
    assert.equal(migConflict.status, 200);
    assert.equal(migConflict.data.migrationStatus, 'conflict_recorded');
    assert.equal(migConflict.data.user.balance, 1450.5);
});
