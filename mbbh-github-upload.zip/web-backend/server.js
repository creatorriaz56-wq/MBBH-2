require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const db = require('./db/adapter');
const { router: authRouter } = require('./routes/auth');
const platformRouter = require('./routes/platform');

function createApp({ serveStaticFrontend = true } = {}) {
    const app = express();

    if (process.env.TRUST_PROXY !== 'false') {
        app.set('trust proxy', 1);
    }

    app.use(helmet({
        crossOriginResourcePolicy: { policy: 'cross-origin' },
        contentSecurityPolicy: false
    }));

    const allowedOriginsRaw = process.env.ALLOWED_ORIGINS || 'https://creatorriaz56-wq.github.io,http://localhost:4000,http://127.0.0.1:4000';
    const allowedOrigins = new Set(
        allowedOriginsRaw.split(',').map((o) => o.trim().replace(/\/$/, '')).filter(Boolean)
    );

    app.use(cors({
        origin(origin, callback) {
            // Allow same-origin / server-to-server / native mobile requests with no Origin header
            if (!origin) return callback(null, true);
            const normalized = origin.replace(/\/$/, '');
            if (allowedOrigins.has(normalized)) {
                return callback(null, true);
            }
            return callback(new Error(`Origin not allowed by CORS: ${origin}`));
        },
        credentials: true,
        methods: ['GET', 'POST', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization']
    }));

    app.use(express.json({ limit: '32kb' }));

    app.get('/api/v1/health', async (_req, res) => {
        try {
            await db.query('SELECT 1 AS ok');
            const info = db.getDbInfo();
            return res.json({
                status: 'ok',
                service: 'MBBH Shared Web & Mobile Backend',
                database: info.mode,
                time: new Date().toISOString()
            });
        } catch (err) {
            return res.status(503).json({
                status: 'error',
                message: 'Database health check failed'
            });
        }
    });

    app.use('/api/v1/auth', authRouter);
    app.use('/api/v1/platform', platformRouter);

    // For local verification in AI Studio, optionally serve web-frontend/ on the same port
    if (serveStaticFrontend && process.env.SERVE_LOCAL_FRONTEND !== 'false') {
        const frontendDir = path.join(__dirname, '..', 'web-frontend');
        app.use(express.static(frontendDir));
    }

    app.use((err, _req, res, _next) => {
        if (err && err.message && err.message.startsWith('Origin not allowed by CORS')) {
            return res.status(403).json({
                success: false,
                message: 'অবৈধ অরিজিন থেকে অনুরোধ প্রত্যাখ্যান করা হয়েছে।',
                messageEn: 'CORS policy: Origin not allowed.'
            });
        }
        console.error('[MBBH Backend Error]', err);
        return res.status(500).json({
            success: false,
            message: 'সার্ভার প্রক্রিয়াকরণে ত্রুটি ঘটেছে।',
            messageEn: 'Internal server error.'
        });
    });

    return app;
}

if (require.main === module) {
    const port = Number(process.env.PORT || 4000);
    db.initDb()
        .then((info) => {
            const app = createApp();
            app.listen(port, '0.0.0.0', () => {
                console.log(`[MBBH Web Backend] Running on port ${port} (DB mode: ${info.mode})`);
            });
        })
        .catch((err) => {
            console.error('[MBBH Web Backend] Failed to initialize database:', err);
            process.exit(1);
        });
}

module.exports = { createApp };
