-- MBBH Authoritative PostgreSQL Schema (Neon.tech / Supabase Compatible)
-- Run automatically on startup or manually via psql "$DATABASE_URL" -f db/schema.sql

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    phone VARCHAR(11) NOT NULL UNIQUE,
    operator VARCHAR(32) NOT NULL,
    name VARCHAR(80) NOT NULL,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    password_algo VARCHAR(32) NOT NULL DEFAULT 'pbkdf2_100k_64',
    balance NUMERIC(14, 2) NOT NULL DEFAULT 0.00 CHECK (balance >= 0),
    personal_wallet_balance NUMERIC(14, 2) NOT NULL DEFAULT 0.00 CHECK (personal_wallet_balance >= 0),
    vip_tier INTEGER NOT NULL DEFAULT 0 CHECK (vip_tier >= 0 AND vip_tier <= 9),
    vip_expire_days INTEGER NOT NULL DEFAULT 2 CHECK (vip_expire_days >= 0),
    referral_code VARCHAR(32) NOT NULL UNIQUE,
    referred_by VARCHAR(32) DEFAULT NULL,
    bound_account_name VARCHAR(100) DEFAULT NULL,
    bound_wallet_type VARCHAR(20) DEFAULT NULL,
    bound_wallet_number VARCHAR(20) DEFAULT NULL,
    payment_pin_hash TEXT DEFAULT NULL,
    payment_pin_salt TEXT DEFAULT NULL,
    today_earnings NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    yesterday_earnings NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    monthly_earnings NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    referral_income NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    team_commission NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    total_recharged NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    total_withdrawn NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    completed_tasks_today INTEGER NOT NULL DEFAULT 0,
    last_task_reset_date VARCHAR(16) NOT NULL,
    registration_date VARCHAR(16) NOT NULL,
    account_origin VARCHAR(32) NOT NULL DEFAULT 'web_registered',
    migrated_from_device_at TIMESTAMPTZ DEFAULT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(128) NOT NULL UNIQUE,
    client_type VARCHAR(16) NOT NULL DEFAULT 'web',
    user_agent TEXT DEFAULT '',
    ip_address VARCHAR(64) DEFAULT '',
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ DEFAULT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_token_hash ON sessions(token_hash);

CREATE TABLE IF NOT EXISTS captchas (
    id TEXT PRIMARY KEY,
    answer_hash VARCHAR(128) NOT NULL,
    salt VARCHAR(64) NOT NULL,
    ip_address VARCHAR(64) DEFAULT '',
    expires_at TIMESTAMPTZ NOT NULL,
    consumed_at TIMESTAMPTZ DEFAULT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(32) NOT NULL,
    method VARCHAR(32) NOT NULL,
    amount NUMERIC(14, 2) NOT NULL CHECK (amount >= 0),
    balance_before NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    balance_after NUMERIC(14, 2) NOT NULL DEFAULT 0.00 CHECK (balance_after >= 0),
    trx_id VARCHAR(64) NOT NULL UNIQUE,
    status VARCHAR(24) NOT NULL DEFAULT 'PENDING',
    note TEXT DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_user_created ON transactions(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS task_completions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_date VARCHAR(16) NOT NULL,
    track_id VARCHAR(32) NOT NULL,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    reward_amount NUMERIC(14, 2) NOT NULL CHECK (reward_amount >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(user_id, task_date, track_id)
);

CREATE TABLE IF NOT EXISTS referrals (
    id TEXT PRIMARY KEY,
    inviter_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    invited_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    tier INTEGER NOT NULL CHECK (tier >= 1 AND tier <= 3),
    commission_earned NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(inviter_user_id, invited_user_id)
);

CREATE TABLE IF NOT EXISTS auth_audit_logs (
    id TEXT PRIMARY KEY,
    phone VARCHAR(16) NOT NULL,
    action VARCHAR(32) NOT NULL,
    success BOOLEAN NOT NULL,
    ip_address VARCHAR(64) DEFAULT '',
    detail TEXT DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_auth_audit_phone_created ON auth_audit_logs(phone, created_at DESC);

CREATE TABLE IF NOT EXISTS migration_conflicts (
    id TEXT PRIMARY KEY,
    phone VARCHAR(11) NOT NULL,
    existing_user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    existing_balance NUMERIC(14, 2) NOT NULL,
    incoming_balance NUMERIC(14, 2) NOT NULL,
    source VARCHAR(32) NOT NULL,
    payload_json TEXT NOT NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'NEEDS_REVIEW',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
