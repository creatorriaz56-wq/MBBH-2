// Unified Database Adapter:
// Uses PostgreSQL (pg.Pool with TLS) when DATABASE_URL is configured (Neon / Supabase production).
// Uses Node.js built-in SQLite (node:sqlite) locally when DATABASE_URL is empty for zero-cost testing.

const fs = require('fs');
const path = require('path');

let pool = null;
let sqliteDb = null;
let mode = null;

function convertPgSqlToSqlite(sql) {
    // Convert PostgreSQL $1, $2 placeholders -> SQLite ? placeholders in order
    return {
        sql: sql.replace(/\$(\d+)/g, '?'),
        extractParams: (params, originalSql) => {
            const matches = [...originalSql.matchAll(/\$(\d+)/g)];
            if (matches.length === 0) return params;
            return matches.map((m) => {
                const val = params[Number(m[1]) - 1];
                if (typeof val === 'boolean') return val ? 1 : 0;
                return val === undefined ? null : val;
            });
        }
    };
}

const SQLITE_SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    phone TEXT NOT NULL UNIQUE,
    operator TEXT NOT NULL,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    password_algo TEXT NOT NULL DEFAULT 'pbkdf2_100k_64',
    balance REAL NOT NULL DEFAULT 0.00 CHECK (balance >= 0),
    personal_wallet_balance REAL NOT NULL DEFAULT 0.00 CHECK (personal_wallet_balance >= 0),
    vip_tier INTEGER NOT NULL DEFAULT 0 CHECK (vip_tier >= 0 AND vip_tier <= 9),
    vip_expire_days INTEGER NOT NULL DEFAULT 2 CHECK (vip_expire_days >= 0),
    referral_code TEXT NOT NULL UNIQUE,
    referred_by TEXT DEFAULT NULL,
    bound_account_name TEXT DEFAULT NULL,
    bound_wallet_type TEXT DEFAULT NULL,
    bound_wallet_number TEXT DEFAULT NULL,
    payment_pin_hash TEXT DEFAULT NULL,
    payment_pin_salt TEXT DEFAULT NULL,
    today_earnings REAL NOT NULL DEFAULT 0.00,
    yesterday_earnings REAL NOT NULL DEFAULT 0.00,
    monthly_earnings REAL NOT NULL DEFAULT 0.00,
    referral_income REAL NOT NULL DEFAULT 0.00,
    team_commission REAL NOT NULL DEFAULT 0.00,
    total_recharged REAL NOT NULL DEFAULT 0.00,
    total_withdrawn REAL NOT NULL DEFAULT 0.00,
    completed_tasks_today INTEGER NOT NULL DEFAULT 0,
    last_task_reset_date TEXT NOT NULL,
    registration_date TEXT NOT NULL,
    account_origin TEXT NOT NULL DEFAULT 'web_registered',
    migrated_from_device_at TEXT DEFAULT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL UNIQUE,
    client_type TEXT NOT NULL DEFAULT 'web',
    user_agent TEXT DEFAULT '',
    ip_address TEXT DEFAULT '',
    expires_at TEXT NOT NULL,
    revoked_at TEXT DEFAULT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_token_hash ON sessions(token_hash);

CREATE TABLE IF NOT EXISTS captchas (
    id TEXT PRIMARY KEY,
    answer_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    ip_address TEXT DEFAULT '',
    expires_at TEXT NOT NULL,
    consumed_at TEXT DEFAULT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    method TEXT NOT NULL,
    amount REAL NOT NULL CHECK (amount >= 0),
    balance_before REAL NOT NULL DEFAULT 0.00,
    balance_after REAL NOT NULL DEFAULT 0.00 CHECK (balance_after >= 0),
    trx_id TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'PENDING',
    note TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_transactions_user_created ON transactions(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS task_completions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_date TEXT NOT NULL,
    track_id TEXT NOT NULL,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    reward_amount REAL NOT NULL CHECK (reward_amount >= 0),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(user_id, task_date, track_id)
);

CREATE TABLE IF NOT EXISTS referrals (
    id TEXT PRIMARY KEY,
    inviter_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    invited_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    tier INTEGER NOT NULL CHECK (tier >= 1 AND tier <= 3),
    commission_earned REAL NOT NULL DEFAULT 0.00,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(inviter_user_id, invited_user_id)
);

CREATE TABLE IF NOT EXISTS auth_audit_logs (
    id TEXT PRIMARY KEY,
    phone TEXT NOT NULL,
    action TEXT NOT NULL,
    success INTEGER NOT NULL,
    ip_address TEXT DEFAULT '',
    detail TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_auth_audit_phone_created ON auth_audit_logs(phone, created_at DESC);

CREATE TABLE IF NOT EXISTS migration_conflicts (
    id TEXT PRIMARY KEY,
    phone TEXT NOT NULL,
    existing_user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    existing_balance REAL NOT NULL,
    incoming_balance REAL NOT NULL,
    source TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'NEEDS_REVIEW',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`;

async function initDb(options = {}) {
    if (mode) return getDbInfo();
    const databaseUrl = (options.databaseUrl !== undefined ? options.databaseUrl : process.env.DATABASE_URL || '').trim();

    if (databaseUrl) {
        const { Pool } = require('pg');
        pool = new Pool({
            connectionString: databaseUrl,
            ssl: databaseUrl.includes('localhost') || databaseUrl.includes('127.0.0.1')
                ? false
                : { rejectUnauthorized: true },
            max: 10,
            idleTimeoutMillis: 30000
        });
        const schemaSql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf-8');
        await pool.query(schemaSql);
        mode = 'postgres';
    } else {
        const { DatabaseSync } = require('node:sqlite');
        const sqlitePath = options.sqlitePath || process.env.SQLITE_PATH || path.join(__dirname, '..', 'data', 'mbbh_local.sqlite');
        fs.mkdirSync(path.dirname(sqlitePath), { recursive: true });
        sqliteDb = new DatabaseSync(sqlitePath);
        sqliteDb.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
        sqliteDb.exec(SQLITE_SCHEMA);
        mode = 'sqlite';
    }
    return getDbInfo();
}

function getDbInfo() {
    return {
        mode: mode || 'uninitialized',
        isPostgres: mode === 'postgres'
    };
}

async function query(sql, params = []) {
    if (!mode) await initDb();
    if (mode === 'postgres') {
        const res = await pool.query(sql, params);
        return { rows: res.rows, rowCount: res.rowCount };
    }
    const { sql: sqliteSql, extractParams } = convertPgSqlToSqlite(sql);
    const bound = extractParams(params, sql);
    const stmt = sqliteDb.prepare(sqliteSql);
    const trimmed = sqliteSql.trim().toUpperCase();
    if (trimmed.startsWith('SELECT') || /\bRETURNING\b/i.test(sqliteSql)) {
        const rows = stmt.all(...bound);
        return { rows, rowCount: rows.length };
    }
    const info = stmt.run(...bound);
    return { rows: [], rowCount: info.changes || 0 };
}

async function withTransaction(fn) {
    if (!mode) await initDb();
    if (mode === 'postgres') {
        const client = await pool.connect();
        try {
            await client.query('BEGIN ISOLATION LEVEL SERIALIZABLE');
            const tx = {
                query: async (sql, params = []) => {
                    const res = await client.query(sql, params);
                    return { rows: res.rows, rowCount: res.rowCount };
                }
            };
            const result = await fn(tx);
            await client.query('COMMIT');
            return result;
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    }

    // SQLite immediate transaction (serializes writers safely)
    sqliteDb.exec('BEGIN IMMEDIATE');
    try {
        const tx = {
            query: async (sql, params = []) => query(sql, params)
        };
        const result = await fn(tx);
        sqliteDb.exec('COMMIT');
        return result;
    } catch (err) {
        sqliteDb.exec('ROLLBACK');
        throw err;
    }
}

async function closeDb() {
    if (pool) {
        await pool.end();
        pool = null;
    }
    if (sqliteDb) {
        sqliteDb.close();
        sqliteDb = null;
    }
    mode = null;
}

module.exports = {
    initDb,
    getDbInfo,
    query,
    withTransaction,
    closeDb
};
